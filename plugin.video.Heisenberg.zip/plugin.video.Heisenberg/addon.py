# -*- coding: utf-8 -*-

"""
##############################################################
## SPECIAL THANKS TO INSIDE 4NDROID FOR ALL THE HELP!

##############################################################

"""

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

plugin_handle = int(sys.argv[1])

mysettings = xbmcaddon.Addon(id = 'plugin.video.themachine')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

## THESE ARE YOUR SOURCES
live_source = "https://raw.githubusercontent.com/AddonHeisenberg/Canales-TV/master/Opcion1.m3u"
live_source2 = "https://raw.githubusercontent.com/AddonHeisenberg/Canales-TV/master/Opcion2.m3u"
live_source3 = "https://raw.githubusercontent.com/AddonHeisenberg/Canales-TV/master/Opcion3.m3u"
live_source4 = "https://raw.githubusercontent.com/AddonHeisenberg/Canales-TV/master/Opcion4.m3u"
live_source5 = "https://raw.githubusercontent.com/AddonHeisenberg/Canales-TV/master/Opcion5.m3u"
movie_source = "https://raw.githubusercontent.com/AddonHeisenberg/Peliculas/master/MainPeliculas.m3u"
tvshows_source = "https://raw.githubusercontent.com/AddonHeisenberg/Series/master/MainSeries.m3u"

## THESE ARE YOUR REGEX'S
regex = 'name=(.+?)url=(.+)logo=(.+?)'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'

## THIS IS JUST A FILLER FOR THE URL ON MAION CATEGORIES
u_tube = 'http://www.youtube.com'

def removeAccents(s):
## THIS REMOVES ACCENTS FROM TEXT SO THAT PYTHON CAN READ IT
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## THIS FUNCTION READS THE SOURCE FILES
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
## THIS FUNCTION GETS THE FILES FROM URL AND READS THEM TO CACHE/MEM
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def main():
##	THESE ARE THE MENUS
	add_link_info('[B][COLOR gold]** ADDON HEISENBERG**[/COLOR][/B]',icon, fanart)
	add_dir('[COLOR lime][B]>>  BUSCA TU CONTENIDO <<[/B][/COLOR]', 'searchlink', 98, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> TELEVISION<<[/B][/COLOR]', u_tube, 2, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> OPCION 1 <<[/B][/COLOR][COLOR gold]Recomendada[/COLOR]', u_tube, 5, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> OPCION 2<<[/B][/COLOR][COLOR gold]Recomendada[/COLOR]', u_tube, 6, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> OPCIÓN 3 <<[/B][/COLOR]', u_tube, 7, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> OPCION 4<<[/B][/COLOR]', u_tube, 8, icon, fanart)
	add_link_dummy(icon, fanart)
	add_link_info('[B][COLOR gold]** HEISENBERG** [/COLOR][/B]',icon, fanart)
	add_dir('[COLOR lime][B]>>  BUSCA TU PELICULA/SERIE FAVORITA  <<[/B][/COLOR]', 'searchlink', 99, icon, fanart)
	add_dir('[COLOR aquamarine][B]>> CINE <<[/B][/COLOR]', u_tube, 3, icon, fanart)		
	add_dir('[COLOR aquamarine][B]>> SERIES <<[/B][/COLOR]', u_tube, 4, icon, fanart)



def searchtv(): 	
## THIS IS THE SEARCH FUNCTION WHICH SEARCHES THE LIVE TV 
	try:
		keyb = xbmc.Keyboard('', 'Buscador:')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			content1 = make_request(live_source)
			content2 = make_request(live_source2)
			content3 = make_request(live_source3)
			content4 = make_request(live_source4)
			content5 = make_request(live_source5)
			match1 = re.compile(m3u_regex).findall(content1)
			match2 = re.compile(m3u_regex).findall(content2)
			match3 = re.compile(m3u_regex).findall(content3)
			match4 = re.compile(m3u_regex).findall(content4)
			match5 = re.compile(m3u_regex).findall(content5)
			for thumb, name, url in match1+match2+match3+match4+match5:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass
					
def search(): 	
## THIS IS THE SEARCH FUNCTION WHICH SEARCHES MOVIES AND tvshows
	try:
		keyb = xbmc.Keyboard('', 'QUE PELÍCULA/SERIE TE GUSTARÍA VER!? ')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			contentM = make_request(movie_source)
			contentD = make_request(tvshows_source)
			match2 = re.compile(regex).findall(contentM)
			match3 = re.compile(regex).findall(contentD)
			for name, url, thumb in match2+match3:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					playlist(name, url, thumb)	
	except:
		pass
		
def livetv_online():
## GET THE LIVE TV 
	content = make_request(live_source)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def livetv_online2():
## GET THE LIVE TV 
	content = make_request(live_source2)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass			

def livetv_online3():
## GET THE LIVE TV 
	content = make_request(live_source3)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass			

def livetv_online4():
## GET THE LIVE TV 
	content = make_request(live_source4)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def livetv_online5():
## GET THE LIVE TV 
	content = make_request(live_source5)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

		
def movies_online():
## GET THE MOVIES
	content = make_request(movie_source)
	match = re.compile(regex).findall(content)
	for name, url, thumb in match:
		try:
			playlist(name, url, thumb)
		except:
			pass

def tvshows_online():
## GET THE DOCUMENTARIES
	content = make_request(tvshows_source)
	match = re.compile(regex).findall(content)
	for name, url, thumb in match:
		try:
			playlist(name, url, thumb)
		except:
			pass
				
def playlist(name, url, thumb):	
## AFTER GETTING THE MOVIES OR tvshows CATEGORIE OR SEARCHING THESE THIS WILL SORT AND LIST THEM AS DIRS OR LINKS ETC
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def m3u_playlist(name, url, thumb):	
## AFTER GETTING THE LIVETV CATEGORIE OR SEARCHING LIVETV THEN THIS WILL SORT AND LIST THEM AS DIRS OR LINKS ETC
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def play_video(url):
## THIS HAPPENS WHEN A LINK IS CLICKED ON IF THE URL CONTAINS .M3U8 THEN IT WILL DO THE "IF" PART AN IF NOT IT WILL DO THE "ELSE" BIT!
	if '.m3u8'  or '.ts' in url:
		url = url.replace("http://","plugin://plugin.video.f4mTester/?url=http://").replace(".m3u8",".ts")
		url = url + "&amp;streamtype=TSDOWNLOADER"
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return
	else:
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return	

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def add_dir(name, url, mode, iconimage, fanart):
## ADDS THE DIRECTORIES
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok

def add_link(name, url, mode, iconimage, fanart):
## ADDS THE LINKS
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def add_link_info(name, iconimage, fanart):
## ADDS THE TEXT ONLY LINKS WITH NO CLICK ACTION
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 
	
def add_link_dummy(iconimage, fanart):
## ADDS THE BLANK SPACER IN MENU WITH NO CLICK ACTION
	u = sys.argv[0] + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		

## THESE BELOW ARE DIFFERENT MODES WHICH TELLS EACH CLICK WHERE TO GO IN THE ABOVE CODE

if mode == None or url == None or len(url) < 1:
	main()

elif mode == 1:
	play_video(url)

elif mode == 2:
	livetv_online()

elif mode == 3:
	movies_online()
	
elif mode == 4:
	tvshows_online()

elif mode == 98:
	searchtv()

elif mode == 99:
	search()

elif mode == 5:
	livetv_online2()

elif mode == 6:
	livetv_online3()

elif mode == 7:
	livetv_online4()

elif mode == 8:
	livetv_online5()


xbmcplugin.endOfDirectory(plugin_handle)